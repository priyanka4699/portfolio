import { Redis } from "@upstash/redis";

const redis = Redis.fromEnv();

const ID_MIN = 1;
const ID_MAX = 1025; // official-artwork exists reliably in this range
const MAX_RECENT = 40;
const KEY = "pokedrops";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");

  if (req.method === "GET") {
    const [count, recent] = await Promise.all([
      redis.llen(KEY),
      redis.lrange(KEY, -MAX_RECENT, -1),
    ]);
    return res.status(200).json({ count, recent: recent.map(Number) });
  }

  if (req.method === "POST") {
    const added = ID_MIN + Math.floor(Math.random() * (ID_MAX - ID_MIN + 1));
    const count = await redis.rpush(KEY, added);
    return res.status(200).json({ count, added });
  }

  res.status(405).json({ error: "Method not allowed" });
}
